﻿using CategoryMaster.Models;
using ProductMaster.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using PagedList;  

namespace CategoryMaster.Controllers
{
    public class ProdutController : Controller
    {
        //
        // GET: /Produt/

        public ActionResult Index(int? pageNumber)
        {
            ProductCurdOperation Poperation = new ProductCurdOperation();
            ModelState.Clear();
            return View(Poperation.GetProductDetail().ToList().ToPagedList(pageNumber ?? 1, 5));
        }

        public void CategoryBind()
        {
            ProductCurdOperation Poperation = new ProductCurdOperation();
            ProductModel Pmodel = new ProductModel();
            List<CategoryModel> ObjList = new List<CategoryModel>();
            ObjList = Poperation.GetCategory();
            ViewBag.Data = new SelectList(ObjList, "CategoryId", "CategoryName");
        }


        public ActionResult Create(int ?ProductId)
        {
            ProductCurdOperation Poperation = new ProductCurdOperation();
            CategoryBind();
            return View(Poperation.GetProductDetail().Find(cmodel => cmodel.ProductId == ProductId));
            
        }

        [HttpPost]
        [AllowAnonymous]
        [ValidateAntiForgeryToken]
        public ActionResult Create(ProductModel Pmodel)
        {
            try
            {
                ProductCurdOperation Poperation = new ProductCurdOperation();
                if (ModelState.IsValid)
                {
                    string message = string.Empty;
                    if (Pmodel.ProductId == 0 || Pmodel.ProductId==null)
                    {
                            message =Poperation.AddProduct(Pmodel);
                            ViewBag.Message = message;
                            ModelState.Clear();
                        
                    }
                    else
                    {
                        message = Poperation.UpdateDetails(Pmodel);
                        ViewBag.Message = message;
                        

                    }

                }
                CategoryBind();
                return View();
            }
            catch
            {
                return View();
            }
        }

        public ActionResult Delete(int ProductId)
        {
            try
            {
                ProductCurdOperation Poperation = new ProductCurdOperation();
                if (Poperation.DeleteProduct(ProductId))
                {
                    ViewBag.Message = "Product Deleted Successfully";
                }
                return RedirectToAction("Index");
            }
            catch
            {
                return View();
            }
        }

      

	}
}
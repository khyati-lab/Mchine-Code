﻿using CategoryMaster.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;

namespace CategoryMaster.Controllers
{
    public class CategoryController : Controller
    {
        //
        // GET: /Category/
        public ActionResult Index()
        {
            CategoryCurdOperation operation = new CategoryCurdOperation();
            ModelState.Clear();
            return View(operation.GetCategory());
        }

        [HttpPost]
        [AllowAnonymous]
        [ValidateAntiForgeryToken]  
        public ActionResult Create(CategoryModel cmodel)
        {
            try
            {
                if (ModelState.IsValid)
                {
                    if (cmodel.CategoryId == null || cmodel.CategoryId==0)
                    {
                        CategoryCurdOperation coperation = new CategoryCurdOperation();
                        if (coperation.AddCategory(cmodel))
                        {
                            ViewBag.Message = "Category Added Successfully";
                            ModelState.Clear();
                        }
                    }
                    else
                    {
                        CategoryCurdOperation coperation = new CategoryCurdOperation();
                        coperation.UpdateDetails(cmodel);
                        ViewBag.Message = "Category Updated Successfully";
                        
                    }

                }
                return View();
            }
            catch
            {
                return View();
            }
        }
        
        public ActionResult Create(int ?CategoryId)
        {
            CategoryCurdOperation coperation = new CategoryCurdOperation();
            return View(coperation.GetCategory().Find(cmodel => cmodel.CategoryId == CategoryId));
        }

        public ActionResult Delete(int CategoryId)
        {
            try
            {
                CategoryCurdOperation cOperation = new CategoryCurdOperation();
                if (cOperation.DeleteCategory(CategoryId))
                {
                    ViewBag.AlertMsg = "Category Deleted Successfully";
                }
                return RedirectToAction("Index");
            }
            catch
            {
                return View();
            }
        }

    }
}

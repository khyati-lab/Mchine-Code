﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Configuration;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Web;

namespace CategoryMaster.Models
{

    public class CategoryModel
    {
        public int? CategoryId { get; set; }
        [Required]
        [Display(Name = "Category Name")]

        public string CategoryName { get; set; }
    }
    public class CategoryCurdOperation
    {

        private SqlConnection con;
        private void connection()
        {
            string constring = ConfigurationManager.ConnectionStrings["CurdOperation"].ToString();
            con = new SqlConnection(constring);
        }

        // **************** ADD NEW Category *********************
        public bool AddCategory(CategoryModel cmodel)
        {
            connection();
            SqlCommand cmd = new SqlCommand("AddCategory", con);
            cmd.CommandType = CommandType.StoredProcedure;
            cmd.Parameters.AddWithValue("@CategoryName", cmodel.CategoryName);
            con.Open();
            int i = cmd.ExecuteNonQuery();
            con.Close();

            if (i >= 1)
                return true;
            else
                return false;
        }

        // ********** VIEW CATEGORY DETAILS ********************
        public List<CategoryModel> GetCategory()
        {
            connection();
            List<CategoryModel> categorylist = new List<CategoryModel>();

            SqlCommand cmd = new SqlCommand("GetCategoryDetails", con);
            cmd.CommandType = CommandType.StoredProcedure;
            SqlDataAdapter sd = new SqlDataAdapter(cmd);
            DataTable dt = new DataTable();

            con.Open();
            sd.Fill(dt);
            con.Close();

            foreach (DataRow dr in dt.Rows)
            {
                categorylist.Add(
                    new CategoryModel
                    {
                        CategoryId = Convert.ToInt32(dr["CategoryId"]),
                        CategoryName = Convert.ToString(dr["CategoryName"])
                    });
            }
            return categorylist;
        }

        // ***************** UPDATE CTEGORY DETAILS *********************
        public bool UpdateDetails(CategoryModel cmodel)
        {
            connection();
            SqlCommand cmd = new SqlCommand("AddCategory", con);
            cmd.CommandType = CommandType.StoredProcedure;

            cmd.Parameters.AddWithValue("@CategoryId", cmodel.CategoryId);
            cmd.Parameters.AddWithValue("@CategoryName", cmodel.CategoryName);
            con.Open();
            int i = cmd.ExecuteNonQuery();
            con.Close();

            if (i >= 1)
                return true;
            else
                return false;
        }

        // ********************** DELETE CATEGORY DETAILS *******************
        public bool DeleteCategory(int id)
        {
            connection();
            SqlCommand cmd = new SqlCommand("DeleteCategory", con);
            cmd.CommandType = CommandType.StoredProcedure;

            cmd.Parameters.AddWithValue("@CategoryId", id);

            con.Open();
            int i = cmd.ExecuteNonQuery();
            con.Close();

            if (i >= 1)
                return true;
            else
                return false;
        }




    }
}
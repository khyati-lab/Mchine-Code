﻿using CategoryMaster.Models;
using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Configuration;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Web;
using System.Web.WebPages.Html;

namespace ProductMaster.Models
{
    public class ProductModel
    {
        
        public int? ProductId { get; set; }
        [Required]
        public int CategoryId { get; set; }
        public List<ProductModel> Products { get; set; }
        [Required]
        [Display(Name = "Product Name")]
        public string ProductName { get; set; }
        public string CategoryName { get; set; }
    }

    public class ProductCurdOperation
    {
        
        private SqlConnection con;
        private void connection()
        {
            string constring = ConfigurationManager.ConnectionStrings["CurdOperation"].ToString();
            con = new SqlConnection(constring);
        }

        public List<CategoryModel> GetCategory()
        {
            connection();
            List<CategoryModel> categorylist = new List<CategoryModel>();

            SqlCommand cmd = new SqlCommand("GetCategoryDetails", con);
            cmd.CommandType = CommandType.StoredProcedure;
            SqlDataAdapter sd = new SqlDataAdapter(cmd);
            DataTable dt = new DataTable();

            con.Open();
            sd.Fill(dt);
            con.Close();

            foreach (DataRow dr in dt.Rows)
            {
                categorylist.Add(
                    new CategoryModel
                    {
                        CategoryId = Convert.ToInt32(dr["CategoryId"]),
                        CategoryName = Convert.ToString(dr["CategoryName"])
                    });
            }
            return categorylist;
        }

        public string AddProduct(ProductModel Pmodel)
        {
            string message = string.Empty;  
            connection();
            SqlCommand cmd = new SqlCommand("AddProduct", con);
            cmd.CommandType = CommandType.StoredProcedure;
            cmd.Parameters.AddWithValue("@CategoryId", Pmodel.CategoryId);
            cmd.Parameters.AddWithValue("@ProductName", Pmodel.ProductName);
            cmd.Parameters.Add("@FLAG", SqlDbType.Char, 100);
            cmd.Parameters["@FLAG"].Direction = ParameterDirection.Output;
            con.Open();
            cmd.ExecuteNonQuery();
            message = (string)cmd.Parameters["@FLAG"].Value;
            con.Close();
            return message;
        }
        public string UpdateDetails(ProductModel Pmodel)
        {
            string message = string.Empty;  
            connection();
            SqlCommand cmd = new SqlCommand("AddProduct", con);
            cmd.CommandType = CommandType.StoredProcedure;

            cmd.Parameters.AddWithValue("@CategoryId", Pmodel.CategoryId);
            cmd.Parameters.AddWithValue("@ProductName", Pmodel.ProductName);
            cmd.Parameters.AddWithValue("@ProductId", Pmodel.ProductId);
            cmd.Parameters.Add("@FLAG", SqlDbType.Char, 100);
            cmd.Parameters["@FLAG"].Direction = ParameterDirection.Output; 
            con.Open();
            cmd.ExecuteNonQuery();
            message = (string)cmd.Parameters["@FLAG"].Value;
            con.Close();
            return message;
        }

        public List<ProductModel> GetProductDetail()
        {
            connection();
            List<ProductModel> productlist = new List<ProductModel>();

            SqlCommand cmd = new SqlCommand("GetProductDetails", con);
            cmd.CommandType = CommandType.StoredProcedure;
            SqlDataAdapter sd = new SqlDataAdapter(cmd);
            DataTable dt = new DataTable();

            con.Open();
            sd.Fill(dt);
            con.Close();

            foreach (DataRow dr in dt.Rows)
            {
                productlist.Add(
                    new ProductModel
                    {
                        ProductId = Convert.ToInt32(dr["ProductId"]),
                        ProductName = Convert.ToString(dr["ProductName"]),
                        CategoryId = Convert.ToInt32(dr["CategoryId"]),
                        CategoryName = Convert.ToString(dr["CategoryName"])
                    });
            }
            return productlist;
        }
        public bool DeleteProduct(int id)
        {
            connection();
            SqlCommand cmd = new SqlCommand("DeleteProduct", con);
            cmd.CommandType = CommandType.StoredProcedure;

            cmd.Parameters.AddWithValue("@ProductId", id);

            con.Open();
            int i = cmd.ExecuteNonQuery();
            con.Close();

            if (i >= 1)
                return true;
            else
                return false;
        }

    }
}